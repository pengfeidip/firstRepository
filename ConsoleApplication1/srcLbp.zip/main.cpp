


#include <opencv2/highgui.hpp>
#include "FVR_MyLbp.h"
using namespace std;
int main(int argc, char* argv[]) {

	Mat imageGabor = imread("001_L_1_1.bmp", IMREAD_GRAYSCALE);

	if (imageGabor.empty()) {
		return 0;
	}

	Mat imageLbp;// = Mat::zeros(120, 260, CV_8UC1);
	FVR_MyLbp myLbp;

	imageLbp = myLbp.FVR_lineShiftLBP(imageGabor, 7);

	imshow("imageLbp", imageLbp);
	waitKey();

	return 0;

}
