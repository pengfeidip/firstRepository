/*
 * FVR_MyLbp.cpp
 *
 *  Created on: 2018-4-11
 *      Author: xudb
 */

#include "FVR_MyLbp.h"

FVR_MyLbp::FVR_MyLbp() {
	// TODO Auto-generated constructor stub

}

FVR_MyLbp::~FVR_MyLbp() {
	// TODO Auto-generated destructor stub
}
/*
 * 生成滤波器
 * 滤波器的方向参数，
 * dir == verDir :第一列为1,2,3,...：生成向上的滤波器;
 * dir == horDir :第二列为1,2,3,...：生成向左的滤波器
 */
Mat FVR_MyLbp::FVR_generateShiftLLBP(int rows, DirLbp dir){

	unsigned char i;
#if 0
	Mat tmpl = Mat::zeros(rows, 2, CV_8UC1);
	for(i=0; i<rows; i++)
		tmpl.at<unsigned char>(i,dir == horDir) = i;
#else
	Mat tmpl = Mat::zeros(rows, 2, CV_32FC1);
	for(i=0; i<rows; i++)
		tmpl.at<float>(i,dir == horDir) = i + 1;
#endif



	return tmpl;
}
/*
 * inImg            输入的图片
 * nFiltDims      一个二维向量, 表示横纵滤波器的大小
 * isScale          像素值归一化至[0, 1],方便计算.
 *targetClass   指明输输出的数据类型
*/
Mat FVR_MyLbp::FVR_lineShiftLBP(Mat imageIn, int nFiltDims ){
	//构建四个方向的滤波器
	//if(imageIn.channels() > 1)cvtColor(imageIn, imageIn, CV_GRAY2BGR);
	//printf("%s:%d\r\n",__FUNCTION__,__LINE__);
	imageIn.convertTo(imageIn, CV_32FC1, 1, 0);
	Mat upFiltLLBP, downFiltLLBP, leftFiltLLBP, rigthFiltLLBP;

	upFiltLLBP = FVR_generateShiftLLBP(nFiltDims, verDir);
	downFiltLLBP = upFiltLLBP * -1;
	leftFiltLLBP = FVR_generateShiftLLBP(nFiltDims, horDir);
	rigthFiltLLBP = leftFiltLLBP * -1;

//	cout << "upFiltLLBP = " << endl << " " << upFiltLLBP << endl << endl;
//	cout << "downFiltLLBP = " << endl << " " << downFiltLLBP << endl << endl;
//	cout << "leftFiltLLBP = " << endl << " " << leftFiltLLBP << endl << endl;
//	cout << "rigthFiltLLBP = " << endl << " " << rigthFiltLLBP << endl << endl;
	Mat upLLBP, downLLBP, leftLLBP, rightLLBP;
	// Calculate 2 Vertical Line components
	//利用垂直滤波器(上和下)计算LBP
	upLLBP    = FVR_shiftBasedLBP(imageIn, upFiltLLBP );
	downLLBP  = FVR_shiftBasedLBP(imageIn, downFiltLLBP );

	// Calculate 2 Horizontal Line components
	//利用水平滤波器(左和右)计算LBP
	leftLLBP  = FVR_shiftBasedLBP(imageIn, leftFiltLLBP);
	rightLLBP = FVR_shiftBasedLBP(imageIn, rigthFiltLLBP);

//	leftLLBP.convertTo(leftLLBP, CV_32FC1, 1.0/255, 0);
//	rightLLBP.convertTo(rightLLBP, CV_32FC1, 1.0/255, 0);
//	upLLBP.convertTo(upLLBP, CV_32FC1, 1.0/255, 0);
//	downLLBP.convertTo(downLLBP, CV_32FC1, 1.0/255, 0);

	Mat vertLLBP, horzLLBP;
	vertLLBP = 0.7*(leftLLBP + rightLLBP) ;
	horzLLBP = 0.3*(upLLBP + downLLBP);

#if 1
	Mat LLBP ;//= Mat::zeros(imageIn.size(),CV_32F) ;
	magnitude(vertLLBP, horzLLBP, LLBP);
#else
	Mat LLBP = horzLLBP.mul(horzLLBP) + vertLLBP.mul(vertLLBP);
	sqrt(LLBP, LLBP);
#endif

	normalize(LLBP, LLBP, 1.0, 0.0, CV_MINMAX);//归一化到0-1
	LLBP.convertTo(LLBP, CV_8UC1, 255, 0);
	return LLBP;
}
/*
 * 根据输入的滤波器来求取LBP图
 * 输入参数
 * inImg- 输入图
 * filtR- 滤波器的大小参数
 * 输出参数LBP-    LBP image UINT8/UINT16/UINT32/UINT64/DOUBLE of same dimentions
 * */
Mat FVR_MyLbp::FVR_shiftBasedLBP(Mat imageIn, Mat imageFilter){

	std::vector<cv::Mat> imageArrays;
	vector<cv::Mat>::iterator it ;
	int nNeigh = imageFilter.size().height;
	int iShift;
	Mat imageSum = Mat::zeros(imageIn.size(), CV_32FC1);
	for (iShift = 0; iShift < nNeigh; iShift++){
		Mat differ = imageIn.clone();
		FVR_circshift(differ, Point(iShift + 1, 0));
		Mat delt = differ - imageIn;
		imageArrays.push_back(delt);
	}
	for (it = imageArrays.begin(), iShift = 1;it != imageArrays.end();it++, iShift++){
		Mat binaryWord = Mat::ones(imageIn.size(), CV_32FC1);
		binaryWord *= pow(2,iShift - 1);
		//cout << "binaryWord = " << endl << " " << binaryWord << endl << endl;
		Mat imageTmp = binaryWord.mul((*it));
		//cout << "index =  " << iShift << endl << " " << *it << endl << endl;
		//cout << "mul = " << endl << " " << imageTmp << endl << endl;
		scaleAdd(binaryWord, 1, imageTmp, imageSum);//imageSum=binaryWord*1+imageTmp;
	}
	//cout << "Sum = " << endl << " " << imageSum << endl << endl;
	return imageSum;
}
/*
 * matlab circshift
 *
 * */
void FVR_MyLbp::FVR_circshift(Mat &imageIn, const Point &delta){

	Size sz = imageIn.size();

	// 错误检查
	assert(sz.height > 0 && sz.width > 0);
	// 此种情况不需要移动
	if ((sz.height == 1 && sz.width == 1) || (delta.x == 0 && delta.y == 0))
		return;

	// 需要移动参数的变换，这样就能输入各种整数了
	int x = delta.x;
	int y = delta.y;
	if (x > 0) x = x % sz.width;
	if (y > 0) y = y % sz.height;
	if (x < 0) x = x % sz.width + sz.width;
	if (y < 0) y = y % sz.height + sz.height;


	// 多维的Mat也能移动
	vector<Mat> planes;
	split(imageIn, planes);

	for (size_t i = 0; i < planes.size(); i++)
	{
		// 竖直方向移动
		Mat tmp0, tmp1, tmp2, tmp3;
		Mat q0(planes[i], Rect(0, 0, sz.width, sz.height - y));
		Mat q1(planes[i], Rect(0, sz.height - y, sz.width, y));
		q0.copyTo(tmp0);
		q1.copyTo(tmp1);
		tmp0.copyTo(planes[i](Rect(0, y, sz.width, sz.height - y)));
		tmp1.copyTo(planes[i](Rect(0, 0, sz.width, y)));

		// 水平方向移动
		Mat q2(planes[i], Rect(0, 0, sz.width - x, sz.height));
		Mat q3(planes[i], Rect(sz.width - x, 0, x, sz.height));
		q2.copyTo(tmp2);
		q3.copyTo(tmp3);
		tmp2.copyTo(planes[i](Rect(x, 0, sz.width - x, sz.height)));
		tmp3.copyTo(planes[i](Rect(0, 0, x, sz.height)));
	}

	merge(planes, imageIn);
}


