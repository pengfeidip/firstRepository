/*
 * FVR_MyLbp.h
 *
 *  Created on: 2018-4-11
 *      Author: xudb
 */

#ifndef FVR_MYLBP_H_
#define FVR_MYLBP_H_
#include <iostream>


#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core/mat.hpp>
using namespace std;
using namespace cv;

class FVR_MyLbp {
public:
	typedef enum{
		verDir,
		horDir,

	}DirLbp;
	FVR_MyLbp();
	virtual ~FVR_MyLbp();

	Mat FVR_generateShiftLLBP(int rows, DirLbp dir);
	Mat FVR_lineShiftLBP(Mat imageIn, int nFiltDims);
	Mat FVR_shiftBasedLBP(Mat imageIn, Mat imageFilter);
	void FVR_circshift(Mat &imageIn, const Point &delta);
};

#endif /* FVR_MYLBP_H_ */
